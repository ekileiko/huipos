(function(){    
    persistence.defineMigration(1, {
        up: function() {
            console.log('Migration 1 up...');
            this.createTable('CategoryGroups', function(t){
                t.text('name');
            });
        },
        down: function() {
            this.dropTable('CategoryGroups');
        }
    });
    
    persistence.defineMigration(2, {
        up: function() {
            console.log('Migration 2 up...');
            this.createTable('Categories', function(t){
                t.text('name');
                t.integer('type');
                t.boolean('isDefault');
                t.text('categoryGroup');         // foreign key to category group
            });
            this.addIndex('Categories', 'categoryGroup');
        },
        down: function() {
            this.dropTable('Categories');
        }
    });
    
    persistence.defineMigration(3, {
        up: function() {
            console.log('Migration 3 up...');
            this.createTable('Currencies', function(t){
                t.text('code');
                t.text('name');
                t.text('symbol');
            });
            this.addIndex('Currencies', 'code');
        },
        down: function() {
            this.dropTable('Currencies');
        }
    });
    
    persistence.defineMigration(4, {
        up: function() {
            console.log('Migration 4 up...');
            this.createTable('Accounts', function(t){
                t.text('name');
                t.integer('startBalance');
                t.integer('currentBalance');
                t.boolean('isDefault');
                t.boolean('isIncludeInTotal');
                t.text('currency');             // foreign key to currency
            });
            this.addIndex('Accounts', 'currency');
        },
        down: function() {
            this.dropTable('Accounts');
        }
    });
    
    persistence.defineMigration(5, {
        up: function() {
            console.log('Migration 5 up...');
            this.createTable('Operations', function(t){
                t.integer('type');
                t.date('date');
                t.integer('quantity');
                t.integer('sumPerUnit');
                t.integer('rate');
                t.integer('rateType');
                t.integer('currencySum');
                t.text('comment');
                t.text('account');              // foreign key to account
                t.text('destinationAccount');   // foreign key to destinationAccount
                t.text('category');             // foreign key to category
            });
            this.addIndex('Operations', 'account');
            this.addIndex('Operations', 'destinationAccount');
            this.addIndex('Operations', 'category');
        },
        down: function() {
            this.dropTable('Operations');
        }
    });
    
    
    // Database initialization migration
    persistence.defineMigration(6, {
        up: function() {
            console.log('Migration 6 up...');
            
            // Income categories
            var categoryGroup = new CategoryGroup({ name: "Work" });
            persistence.add(categoryGroup);
            
            var salaryCategory = new Category({ name: "Salary", type: 1, isDefault: true, categoryGroup: categoryGroup });
            persistence.add(salaryCategory);
            persistence.add(new Category({ name: "Prepayment", type: 1, isDefault: false, categoryGroup: categoryGroup }));
            persistence.add(new Category({ name: "Bonus", type: 1, isDefault: false, categoryGroup: categoryGroup }));
            
            // Expense categories
            categoryGroup = new CategoryGroup({ name: "Products" });
            persistence.add(categoryGroup);
            persistence.add(new Category({ name: "Other products", type: 0, isDefault: true, categoryGroup: categoryGroup }));
            persistence.add(new Category({ name: "Vegetables", type: 0, isDefault: false, categoryGroup: categoryGroup }));
            persistence.add(new Category({ name: "Fruits", type: 0, isDefault: false, categoryGroup: categoryGroup }));
            persistence.add(new Category({ name: "Meat", type: 0, isDefault: false, categoryGroup: categoryGroup }));
            persistence.add(new Category({ name: "Drinks", type: 0, isDefault: false, categoryGroup: categoryGroup }));
            
            categoryGroup = new CategoryGroup({ name: "Auto" });
            persistence.add(categoryGroup);
            persistence.add(new Category({ name: "Service", type: 0, isDefault: false, categoryGroup: categoryGroup }));
            var fuelCategory = new Category({ name: "Fuel", type: 0, isDefault: false, categoryGroup: categoryGroup });
            persistence.add(fuelCategory);
            persistence.add(new Category({ name: "Parts", type: 0, isDefault: false, categoryGroup: categoryGroup }));
            
            var currency = new Currency({ code: "840", name: "USD", symbol: "$" });
            persistence.add(currency);
            
            var visaGoldAccount = new Account({ name: "[$] Visa Gold", startBalance: 0.0, currentBalance: 0.0, isDefault: true, isIncludeInTotal: true, currency: currency });
            var pocketAccount = new Account({ name: "[$] Pocket", startBalance: 0.0, currentBalance: 0.0, isDefault: false, isIncludeInTotal: true, currency: currency });
            persistence.add(visaGoldAccount);
            persistence.add(pocketAccount);
            
            currency = new Currency({ code: "978", name: "EUR", symbol: "€" });
            persistence.add(currency);
            
            var visaPlatinumAccount = new Account({ name: "[€] Visa Platinum", startBalance: 0.0, currentBalance: 0.0, isDefault: false, isIncludeInTotal: true, currency: currency });
            var depositAccount = new Account({ name: "[€] Deposit", startBalance: 0.0, currentBalance: 0.0, isDefault: false, isIncludeInTotal: true, currency: currency });
            persistence.add(visaPlatinumAccount);
            persistence.add(depositAccount);
            persistence.flush();
                    
            for(var i = 0; i < 10; i++){
                persistence.add(new Operation({ type: 1, date: Date.now(), quantity: 1, sumPerUnit: 1000, comment: "First salary!", category: salaryCategory, account: visaGoldAccount }));
                persistence.add(new Operation({ type: 0, date: Date.now(), quantity: 1, sumPerUnit: 45, comment: "First filling!", category: fuelCategory, account: visaGoldAccount }));
                persistence.add(new Operation({ type: 2, date: Date.now(), sumPerUnit: 275, rate: 1.1, rateType: 1, currencySum: 250, comment: "First transfer to deposit!", account: visaGoldAccount, destinationAccount: depositAccount }));
                persistence.flush();
            }
        },
        down: function() {
            
        }
    });
})();