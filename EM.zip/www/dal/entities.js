var CategoryGroup = persistence.define('CategoryGroups', {
    name: "TEXT",
});

// ########################################################################################

var Category = persistence.define('Categories', {
    name: "TEXT",
    type: "INT",            // 0 - expense, 1 - income
    isDefault: "BOOL"       // will be choose by default in select-control. 
                            // You can choose one default category among expense categories 
                            // and one among income categories
});
Category.hasOne('categoryGroup', CategoryGroup);

// ########################################################################################

var Currency = persistence.define('Currencies', {
    code: "TEXT",
    name: "TEXT",
    symbol: "TEXT"          // $, rub, b.rub ...
});

// ########################################################################################

var Account = persistence.define('Accounts', {
    name: "TEXT",
    startBalance: "INT",    // INT - not int, but numeric values
    currentBalance: "INT",
    isDefault: "BOOL",
    isIncludeInTotal: "BOOL",
});
Account.hasOne('currency', Currency);

// ########################################################################################

var Operation = persistence.define('Operations', {
    type: "INT",            // 0 - expense, 1 - income, 2 - transfer
    date: "DATE",
    quantity: "INT",
    sumPerUnit: "INT",
    rate: "INT",
    rateType: "INT",        // 0 - currencySum = sumPerUnit * rate, 1 - currencySum = sumPerUnit / rate
    currencySum: "INT",
    comment: "TEXT"
});
Operation.hasOne('account', Account);               // destination account for income opertion, source account for expense and transfer operations
Operation.hasOne('destinationAccount', Account);    // destination account for transfer operation
Operation.hasOne('category', Category);             // source category for income opertion, destination category for expense operation