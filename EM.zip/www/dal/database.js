window.database = (function () {
    var dbName = "emDatabase.db",
        dbVersion =  "1.0.0",
        dbDisplayName =  "Expense Manager Database",
        dbSize =  5*1024*1024;
            
    function Database(){
        
    }
    
    Database.prototype.init = function(callback){
        console.log('database init');
        persistence.store.websql.config(
            persistence,
            dbName,
            dbVersion,
            dbDisplayName,
            dbSize
        );
        //persistence.schemaSync();
        database.migrate(callback);
    };
    
    Database.prototype.migrate = function (callback){
        console.log('migration start...');
        persistence.migrations.init( function(){
            console.log('migration init');
            // this should migrate up to the latest version
            persistence.migrate( function(){
                console.log('migration complete!');
                callback();
            } );
        });
    };
    
    return new Database();
}());