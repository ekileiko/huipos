app.factory('categoriesService', function () {
    console.log('CategoriesService init...');
    return {
        getAllCategoryGroups: function (callback) {
            persistence.transaction(
                function(tx) {
                    tx.executeSql(
                        "SELECT c.id, c.name, Count(s.Id) as categoriesCount " + 
                        "FROM CategoryGroups c " + 
                        "LEFT JOIN Categories s ON s.categoryGroup = c.id " + 
                        "GROUP BY c.id",
                        null,
                        function(results){
                            callback(results);
                        }
                    );
                }
            );
        },
        getCategoriesByGroupId: function (categoryGroup, callback) {
            Category.all().filter('categoryGroup', '=', categoryGroup).list(null, function(results){
                callback(results);
            });
        }
    };
});