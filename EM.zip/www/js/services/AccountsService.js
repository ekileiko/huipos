app.factory('accountsService', [function () {
    console.log('AccountsService init...');
    
    var setAccountBalance = function(accountId, newBalance){
        var deferred = new $.Deferred();
        Account.load(accountId, function(item) {
            item.currentBalance = newBalance;
            persistence.flush();
            console.log('Setting account current balance completed. AccountId: ' + accountId + '. Balance: ' + newBalance);
            deferred.resolve();
        });
        return deferred.promise();
    };
    
    return {        
        getAllAccounts: function (callback) {
            var deferred = new $.Deferred();
            Account.all().prefetch("currency").list(null, function(results) {
                if(callback) callback(results);
                deferred.resolve();
            });
            return deferred.promise();
        },
        reculculateAccountBalances: function (callback){
            console.log('reculculateAccountBalances started...');
            
            Account.all().list(null, function (accounts){
                var accountsBalances = {};
                for(var i = 0; i < accounts.length; i++){
                    accountsBalances[accounts[i].id] = accounts[i].startBalance;
                }
            
                Operation.all().list(null, function(operations) {
                    for(var i = 0; i < operations.length; i++){
                        var account = operations[i].account;
                        var destinationAccount = operations[i].destinationAccount;
                        
                        switch(operations[i].type){
                            case 0:
                                // expense
                                accountsBalances[account.id] -= (operations[i].quantity * operations[i].sumPerUnit);
                                break;
                            case 1:
                                // income
                                accountsBalances[account.id] += (operations[i].quantity * operations[i].sumPerUnit);
                                break;
                            case 2:
                                // transfer
                                accountsBalances[account.id] -= operations[i].sumPerUnit;
                                accountsBalances[destinationAccount.id] += operations[i].currencySum;
                                break;
                            default:
                                break;
                        }
                    }
                    console.debug('accountsBalances: ' + JSON.stringify(accountsBalances));
                    
                    var deferrers = [];
                    for (var prop in accountsBalances) {
                        deferrers.push[setAccountBalance(prop, accountsBalances[prop])];
                    }
                    $.when.apply($, deferrers).then(function(){
                        console.log('reculculateAccountBalances completed...');
                        callback();
                    });
                });
            });
        },
    };
}]);