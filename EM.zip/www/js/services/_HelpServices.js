app.factory('getWatchCountService', function () {
    // I return the count of watchers on the current page
    function getWatchCount(){
        var total = 0;
        $(".ng-scope").each(function(){            
            var scope = angular.element($(this)).scope();
            total += scope.$$watchers 
                ? scope.$$watchers.length
                : 0;
        });
        return (total);
    }
    getWatchCount.bookmarklet = (
        "javascript:alert('Watchers:'+(" +
        getWatchCount.toString().replace(/\/\/.*/g, " ").replace(/\s+/g, " ") +
        ")());void(0);"
    );    
    
    return (getWatchCount);
});