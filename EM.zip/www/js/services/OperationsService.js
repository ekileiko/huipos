app.factory('operationsService', function () {
    console.log('OperationsService init...');
    return {
        getAllOperations: function (callback) {
            console.log('!!! getAllOperations started');
            persistence.transaction(
                function(tx) {
                    tx.executeSql(
                        "SELECT o.id, o.type, o.date, o.quantity, o.sumPerUnit, o.rate, o.rateType, o.currencySum, o.comment, " +
                        "c.id as category_id, c.name as category_name, c.type as category_type, c.isDefault as category_isDefault, " + 
                        "a.id as account_id, a.name as account_name, a.startBalance as account_startBalance, a.currentBalance as account_currentBalance, a.isDefault as account_isDefault, a.isIncludeInTotal as account_isIncludeInTotal, " + 
                        "da.id as dAccount_id, da.name as dAccount_name, da.startBalance as dAccount_startBalance, da.currentBalance as dAccount_currentBalance, da.isDefault as dAccount_isDefault, da.isIncludeInTotal as dAccount_isIncludeInTotal, " + 
                        "cur.id as currency_id, cur.code as currency_code, cur.name as currency_name, cur.symbol as currency_symbol, " +
                        "dcur.id as dCurrency_id, dcur.code as dCurrency_code, dcur.name as dCurrency_name, dcur.symbol as dCurrency_symbol " +
                        
                        "FROM Operations o " + 
                        "LEFT JOIN Categories   c    ON c.id =    o.category " + 
                        "LEFT JOIN Accounts     a    ON a.id =    o.account " +
                        "LEFT JOIN Accounts     da   ON da.id =   o.destinationAccount " +
                        "LEFT JOIN Currencies   cur  ON cur.id =  a.currency " +
                        "LEFT JOIN Currencies   dcur ON dcur.id = da.currency ",
                        null,
                        function(results){
                            console.log('!!! getAllOperations completed. operations.length: ' + results.length);
                            var operations = [];
                            $(results).each(function(index, value){
                                operations.push(new OperationViewModel({
                                    id: value.id,
                                    type: value.type,
                                    // using persistancejs function, read more in persistence.store.sql.js
                                    date: defaultTypeMapper.dbValToEntityVal(value.date, 'DATE'), 
                                    quantity: value.quantity,
                                    sumPerUnit: value.sumPerUnit,
                                    rate: value.rate,
                                    rateType: value.rateType,
                                    currencySum: value.currencySum,
                                    comment: value.comment,
                                    category: new CategoryViewModel({
                                        id: value.category_id,
                                        name: value.category_name,
                                        type: value.category_type,
                                        isDefault: value.category_isDefault,
                                        categoryGroup: new CategoryGroupViewModel()
                                    }),
                                    account: new AccountViewModel({
                                        id: value.account_id,
                                        name: value.account_name,
                                        startBalance: value.account_startBalance,
                                        currentBalance: value.account_currentBalance,
                                        isDefault: value.account_isDefault,
                                        isIncludeInTotal: value.account_isIncludeInTotal,
                                        currency: new CurrencyViewModel({
                                            id: value.currency_id,
                                            code: value.currency_code,
                                            name: value.currency_name,
                                            symbol: value.currency_symbol
                                        })
                                    }),
                                    destinationAccount: new AccountViewModel({
                                        id: value.dAcount_id,
                                        name: value.dAccount_name,
                                        startBalance: value.dAccount_startBalance,
                                        currentBalance: value.dAccount_currentBalance,
                                        isDefault: value.dAccount_isDefault,
                                        isIncludeInTotal: value.dAccount_isIncludeInTotal,
                                        currency: new CurrencyViewModel({
                                            id: value.dCurrency_id,
                                            code: value.dCurrency_code,
                                            name: value.dCurrency_name,
                                            symbol: value.dCurrency_symbol
                                        })
                                    })
                                }));    
                            });
                            if(callback) callback(operations);
                        }
                    );
                }
            );
            
            /*
            Operation
            .all()
            .prefetch("account")
            .prefetch("destinationAccount")
            .list(null, function(operations) {
                console.log('!!! getAllOperations completed. operations.length: ' + operations.length);
                callback(operations);
            });*/
        },
        getAllOperationsByAccountId: function (accountId, accountIndex, callback) {
            Operation
            .all()
            .filter('account', '=', accountId)
            .or(new persistence.PropertyFilter('destinationAccount', '=', accountId))
            .list(null, function(operations) {
                console.log('!!! getAllOperationsByAccountId. operations.length for accountId ' + accountId + ': ' + operations.length);
                callback(accountIndex, operations);
            });
        },
    };
});