app.controller('BaseController', ['$scope', 'getWatchCountService', function($scope, getWatchCountService) {
    console.log('BaseController init...');
    
    // #####################################################################
    // getWatchCountService
    $scope.watchCount = 0;
    $scope.showWatchCount = function(){
        alert('Watch count: ' + $scope.watchCount);
    };
    $scope.$watch(
        function watchCountExpression(){
            return(getWatchCountService());
        },
        function handleWatchCountChange(newValue){
            $scope.watchCount = newValue;
        }
    );
    // #####################################################################
}]);