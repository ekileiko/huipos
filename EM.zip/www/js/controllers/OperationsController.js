app.controller('OperationsController', ['$scope', '$controller', '$cacheFactory', 'operationsService', function($scope, $controller, $cacheFactory, operationsService) {
    console.log('OperationsController init...');
    
    // initialize cache factory
    var cacheId = 'operations';
    $scope.cache = $cacheFactory.get(cacheId);
    if(!$scope.cache)
        $scope.cache = $cacheFactory(cacheId);
        
    // instantiate base controller
    $controller('BaseController', { $scope: $scope });
    
    $scope.operations = [ ];
    
    $scope.init = function(){        
        var cacheKey = 'operationsKey';
        var operations = $scope.cache.get(cacheKey);
        if (operations === undefined) {
            $scope.getAllOperations(function(operations){
                $scope.operations = operations;
                $scope.cache.put(cacheKey, $scope.operations);
                $scope.$digest();
            });
        }
        else {
            $scope.operations = operations;
        }
    };
    
    $scope.getAllOperations = function (callback){
        operationsService.getAllOperations(function(results){
            if(callback) callback(results);
        });
    };
}]);