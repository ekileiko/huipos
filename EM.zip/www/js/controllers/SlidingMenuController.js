app.controller('SlidingMenuController', ['$scope', function($scope){
    console.log('SlidingMenuController init...');
    
    $scope = app;
    $scope.checkSlidingMenuStatus = function(){
        $scope.slidingMenu.on('postclose', function(){
            $scope.slidingMenu.setSwipeable(false);
        });
        $scope.slidingMenu.on('postopen', function(){
            $scope.slidingMenu.setSwipeable(true);
        });
    };
    
    $scope.checkSlidingMenuStatus();
}]);