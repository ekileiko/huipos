app.controller('AccountsController', ['$scope', '$controller', 'accountsService', function($scope, $controller, accountsService) {
    console.log('AccountsController init...');
    
    // instantiate base controller
    $controller('BaseController', { $scope: $scope });
    
    $scope.dialogs = {};
    $scope.accounts = [ ];
    $scope.currenciesAndAccounts = [ ];
    
    $scope.init = function(){
        accountsService.reculculateAccountBalances(function(){
            $scope.getAllAccounts();
        });
    };
    
    $scope.getAllAccounts = function (){
        $scope.accounts = [ ];
        $scope.currenciesAndAccounts = [ ];
        
        accountsService.getAllAccounts(function(results){
            $scope.accounts = results;
            
            $(results).each(function(){
                var account = this;
                var index = 0;
                var currencyExist = false;
                
                for(var i = 0; i < $scope.currenciesAndAccounts.length; i++) {
                    if($scope.currenciesAndAccounts[i].id == account.currency.id) {
                        currencyExist = true;
                        index = i;
                        break;
                    }
                }
                
                if(!currencyExist) {
                    index = $scope.currenciesAndAccounts.push(account.currency) - 1;
                    $scope.currenciesAndAccounts[index].accounts = new Array();
                }
                $scope.currenciesAndAccounts[index].accounts.push(account);
            });
            console.debug('$scope.accounts: ' + JSON.stringify($scope.accounts));
            console.debug('$scope.accounts.length: ' + $scope.accounts.length);
            console.debug('$scope.currenciesAndAccounts: ' + JSON.stringify($scope.currenciesAndAccounts));
            console.debug('$scope.currenciesAndAccounts.length: ' + $scope.currenciesAndAccounts.length);
            $scope.$digest();
        });
    };
    
    $scope.setDefaultAccount = function($event, accountId){
        console.debug('setDefaultAccount. accountId = ' + accountId);
        $($scope.currenciesAndAccounts).each(function(index1){
            $(this.accounts).each(function(index2){
                if(this.id == accountId)
                    $scope.currenciesAndAccounts[index1].accounts[index2].isDefault = true;
                else
                    $scope.currenciesAndAccounts[index1].accounts[index2].isDefault = false;
            });
        });
        $event.stopPropagation();
        $event.preventDefault();
    };
    
    $scope.getTotal = function(index){
        var sum = 0;
        $($scope.currenciesAndAccounts[index].accounts).each(function(){
            if(this.isIncludeInTotal)
                sum += this.currentBalance;
        });
        return sum;
    };
    
    $scope.showMenu = function(accountId){
        var dlg = 'contextMenu.html';
        if (!$scope.dialogs[dlg]) {
            ons.createDialog(dlg).then(function(dialog) {
                $scope.dialogs[dlg] = dialog;
                dialog.show();
            });
        }
        else {
            $scope.dialogs[dlg].show();
        }   
    };
}]);