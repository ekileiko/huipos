app.controller('CategoriesController', ['$scope', 'categoriesService', function($scope, categoriesService) {
    console.log('CategoriesController init...');
        
    $scope.categoryGroups = [ ];
    $scope.categories = [ ];
    
    $scope.getAllCategoryGroups = function (){
        categoriesService.getAllCategoryGroups(function(results){
            $scope.categoryGroups = results;
            console.log('$scope.categoryGroups: ' + JSON.stringify($scope.categoryGroups));
            console.log('$scope.categoryGroups.length: ' + $scope.categoryGroups.length);
            $scope.$apply();
        });
    };
    
    $scope.getCategoriesByGroupId = function (categoryGroup){
        categoriesService.getCategoriesByGroupId(categoryGroup, function(results){
            $scope.categories = results;
            console.log('$scope.categories.length: ' + $scope.categories.length);
            $scope.$apply();
        });
    };
}]);