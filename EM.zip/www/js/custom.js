console.logProperties = function(obj){
    var props = [];
    
    // Logging property names and values using Array.forEach
    Object.getOwnPropertyNames(obj).forEach(function(p, idx, array) {
        props.push({ "property": p, "value": ''/*obj[p]*/});
    });
    
    console.log(props.map(function(elem){
        return '{' + elem.property + ': ' + elem.value + '}';
    }).join(", "));
};