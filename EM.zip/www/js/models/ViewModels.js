function CurrencyViewModel(o){
    this.id;
    this.code = null;
    this.name = null;
    this.symbol = null;
    
    $.extend(this, o);
}

function AccountViewModel(o){
    this.id;
    this.name = null;
    this.startBalance = null;
    this.currentBalance = null;
    this.isDefault = null;
    this.isIncludeInTotal = null;
    
    this.currency = null;
    
    $.extend(this, o);
}

function CategoryGroupViewModel(o){
    this.id;
    this.name = null;
    
    $.extend(this, o);
}

function CategoryViewModel(o){
    this.id;
    this.name = null;
    this.type = null;
    this.isDefault = null;
    
    this.categoryGroup = null;
    
    $.extend(this, o);
}

function OperationViewModel(o) {
    this.id;
    this.type = null;
    this.date = null;
    this.quantity = null;
    this.sumPerUnit = null;
    this.rate = null;
    this.rateType = null;
    this.currencySum = null;
    this.comment = null;
    
    this.account = null;
    this.destinationAccount = null;
    this.category = null;
    
    $.extend(this, o);
}